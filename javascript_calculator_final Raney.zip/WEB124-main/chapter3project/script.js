// Kate Raney
// April 3, 2025

// Full name
let fullName = "Kate Raney";
console.log("Full Name:", fullName);

// Desired annual salary
let desiredSalary = 120000;
console.log("Desired Salary:", desiredSalary);

// Veteran status
let isVeteran = false;
console.log("Veteran Status:", isVeteran);

// Array of three friends
let friends = ["Alex", "Jordan", "Taylor"];
console.log("Friends:", friends);

// Friends' desired salaries
let friendsSalaries = [85000, 95000, 75000];
console.log("Friends' Salaries:", friendsSalaries);

// Object for another friend
let anotherFriend = {
  firstName: "Sam",
  lastName: "Johnson",
  desiredSalary: 108000
};
console.log("Another Friend:", anotherFriend);
